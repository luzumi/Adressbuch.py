from tkinter import *
from Telefonbuch import *



master = Tk()               #erstellt Fenster
master.title("contacts")    #Fenstertitel ändern
master.geometry("500x300")  #Fenstergöße

class Fenster():
    """description of class"""
    vorname = " "
    name = " "
    telefon = " "
    
    def __init__(self,vorname,name,telefon):
          
        eingabeVorname = Entry(master, textvariable=vorname)
        eingabeVorname.pack()
        lVorname= Label(master, text="Vorname")
        lVorname.pack()

        eingabeName = Entry(master, textvariable=name)
        eingabeName.pack()
        lName= Label(master, text="Name")
        lName.pack()
        
        eingabeTelefon = Entry(master, textvariable=telefon)
        eingabeTelefon.pack()
        lTelefon= Label(master, text="Telefon")
        lTelefon.pack()

        def inputVorname(self,vorname):
            self.vorname=StringVar()
            
            
        def inputName(self,name):
            self.name=StringVar()

        def inputTel(self,telefon):
            self.telefon=StringVar()

        def hinzufuegen(event,vorname,name,telefon):
            inputVorname(self,vorname)
            inputName(self,name)
            inputTel(self,telefon)
            print(Fenster.vorname+Fenster.name+Fenster.telefon)

            


        buttonHinzu = Button(master, text = "Kontakt hinzufügen")
        buttonHinzu.pack()
        buttonHinzu.bind("<Button-1>",hinzufuegen)


test=Fenster("","","")
print(Fenster.vorname+Fenster.name+Fenster.telefon)

mainloop()
        

