from tkinter import *
from Telefonbuch import *

window = Tk()               #erstellt Fenster
window.title("contacts")    #Fenstertitel ändern
window.geometry("500x300")  #Fenstergöße

#
#def ausgabe():      #Funktion zur Ausgabe in console
#    print("abc")
#
#button1 = Button(window,text="Button1", command=ausgabe) #button1 in window
#button1.pack()              #automatisch via Designer angeordnet - .pack()
#                            #zum platzieren .place()
#
#
#
#eingabe1 = Entry(window, text = "Eingabefeld")    #Eingabefeld in window
#eingabe1.pack()
#
#def lesen():
#    print(eingabe1.get())     #get liest eingabe1 und wird über print ausgegeben
    #                          #immer ein string, für zahlen float(eingabe.get())
#    label1.configure(text=(eingabe1.get())) #gibt text im label aus
#
#button2 = Button(window, text="read", command = lesen)
#button2.pack()              #button liest eingabe1 ein und gibt auf console aus
#



def inputVorname(vorname):
    vorname=str(eingabeVorname.get())
    return vorname

def inputName(name):
    name=str(eingabeName.get())
    return name
   
def inputTel(telefon):
     telefon=str(eingabeTelefon.get())
     return telefon

def hinzufuegen():
     inputVorname()
     inputName()
     inputTel()
     
     Telefonbuch.addNummer(vorname,name,telefon)

eingabeVorname = Entry(window, text="Vorname")
eingabeVorname.pack()
lVorname= Label(window, text="Vorname")
lVorname.pack()

eingabeName = Entry(window, text="Nachname")
eingabeName.pack()
lName= Label(window, text="Name")
lName.pack()

eingabeTelefon = Entry(window, text="Telefon")
eingabeTelefon.pack()
lTelefon= Label(window, text="Telefon")
lTelefon.pack()

buttonHinzu = Button(window, text = "Kontakt hinzufügen", command = hinzufuegen)
buttonHinzu.pack()




mainloop()                  #notwendig damit das fenster offen bleibt
